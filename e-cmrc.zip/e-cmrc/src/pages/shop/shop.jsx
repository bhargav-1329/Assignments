import React from "react";
import { PRODUCTS } from "../../products";
import { Product } from "./product";
import "./shop.css";

export const Shop = () => {
  return (
      <div className="products">
        {PRODUCTS.map((product,id) => (
          <Product key={id} data={product} />
        ))}
      </div>
  );
};
